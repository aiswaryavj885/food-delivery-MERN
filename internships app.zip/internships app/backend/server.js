//start the server
const app = require('./app');

const dotenv = require('dotenv');
dotenv.config({path: "./config/config.env"});

//starting the server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
    console.log(`Server is started on port ${process.env.PORT}`);
});